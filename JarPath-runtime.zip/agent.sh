java -cp .:test.jar:tools.jar:JvmAgent.jar Tests.TestAgent2 36911
